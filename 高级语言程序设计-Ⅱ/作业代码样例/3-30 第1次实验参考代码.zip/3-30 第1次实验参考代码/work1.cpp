#include <iostream>	
using namespace std;
															
class People
{
	protected:
		int age; 
		float height;
		float weight;
		static int num;
		
	public:
		People(int a = 0, float h = 0, float w = 0);
		~People();
		void Eatting();
		void Sporting();
		void Sleeping();
		void Show();
		static void ShowNum();
};

People::People(int a, float h, float w)
{
	age = a; height = h; weight = w;
	num++;
}

People::~People()
{
	num--;
}

void People::Eatting()
{
	weight++;
}

void People::Sporting()
{
	height++;
}

void People::Sleeping()
{
	weight++; height++; age++;
}

void People::Show()
{
	cout<<age<<"��"<<height<<"����"<<weight<<"�н�"<<endl; 
}

void People::ShowNum()
{
	cout<<"����Ϊ"<<num<<endl;
}
int People::num = 0;
int main()
{
	People test;
	test.Show();
	test.ShowNum();
	
	test.Eatting(); test.Show();
	test.Sporting(); test.Show();
	test.Sleeping(); test.Show();
	
	People t2;
	t2.ShowNum();
	t2.Show(); 
	
	return 0;
}
