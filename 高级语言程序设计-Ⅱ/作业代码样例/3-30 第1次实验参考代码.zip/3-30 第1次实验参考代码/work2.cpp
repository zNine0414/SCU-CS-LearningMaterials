#include <iostream>	
#include <cstring>
using namespace std;

class Student
{
	private:
		char name[18];
		int num;
		int mathScore;
		int englishScore;
		static int count;
		static int mathTotalScore;
		static int englishTotalScore;
		
	public:
		Student(char* nm, int nu, int math, int english);
		~Student();
		void ShowBase();
		static void ShowStatic();
};

int Student::count = 0;
int Student::mathTotalScore = 0;
int Student::englishTotalScore = 0;

Student::Student(char* nm, int nu, int math, int english)
{
	memcpy(name, nm, strlen(nm));
	num = nu;
	mathScore = math;
	englishScore = english;
	count++;
	mathTotalScore += math;
	englishTotalScore += english;
}

void Student::ShowBase()
{
	cout<<name<<" ѧ��"<<num;
	cout<<" ��ѧ�ɼ�"<<mathScore;
	cout<<" Ӣ��ɼ�"<<englishScore<<endl;
}

void Student::ShowStatic()
{
	cout<<"����"<<count;
	cout<<" ��ѧ�ܳɼ�"<<mathTotalScore;
	cout<<" Ӣ���ܳɼ�"<<englishTotalScore<<endl;
}

Student::~Student()
{
	count--;
	mathTotalScore -= this->mathScore;
	englishTotalScore -= this->englishScore;
}

int main()
{
	char stus[3][18] = {"zhang3", "li4", "test"};
	Student ts1(stus[0], 1111, 55, 55);
	ts1.ShowBase(); ts1.ShowStatic();
	cout<<endl;
	
	Student ts2(stus[1], 2222, 60, 60);
	ts2.ShowBase(); ts2.ShowStatic();
	cout<<endl;
	
	Student ts3(stus[2], 4444, 100, 100);
	ts3.ShowBase(); ts3.ShowStatic();
	
	ts1.~Student();
	Student::ShowStatic();
	
	return 0; 
}
