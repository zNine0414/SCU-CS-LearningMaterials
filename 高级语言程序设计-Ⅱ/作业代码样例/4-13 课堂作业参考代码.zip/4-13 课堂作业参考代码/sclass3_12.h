#ifndef _SCLASS_3_12_H
#define _SCLASS_3_12_H
#include<iostream>   
#include<string.h>     
using namespace std; 

const int LEN = 50; 

class CEducation 
{
public:
	CEducation( ){};
	CEducation( char cSchool[], char cDegree );   
	void GetEdu( void ) ;                
	void PutEdu( void ) const;               
private:
	char m_cSchool[LEN];                    
	char m_cDegree;                       
};

class Staff                                  
{
public:
	Staff( void ){};                          
	~Staff( void ){};                         
	virtual void CalculateSal( void ){};               
	void OutPut( void );                     
	virtual void InPut( void );

protected:
	CEducation Edu;                     
	int m_iStaffNum;                      
	char m_cName[LEN];         	 	    
	float m_fRateOfAttend;    		        
	float m_fBasicSal ;         		   
	float m_fPrize ;       		        
	static int s_iCount;  
};

class CAdminStaff : public Staff             
{
public:	
	CAdminStaff ( ){};                    
	~ CAdminStaff ( ){};               
	void CalculateSal( void )  ;     
};


class CManager : virtual public Staff          
{
public:
	CManager( ){};                        
	void SetMData( void );                  
	void CalculateSal( void );  
	void InPut(void);
protected:
	float m_fDeductTRate;                  
	float m_fTAmount;                    
};

class CSaleman : virtual public Staff
{
public:
	CSaleman ( ){};                     
	void SetSData( void );                 
	void CalculateSal( void )  ;       
	void InPut(void);
protected:
	float m_fDeductRate;                   
	float m_fPersonAmount;              
};

class CSaleManager : public CSaleman, public CManager 
{
public:
	CSaleManager( ){};                                    
	void CalculateSal( void ) ;       
	void InPut(void);
};

#endif
