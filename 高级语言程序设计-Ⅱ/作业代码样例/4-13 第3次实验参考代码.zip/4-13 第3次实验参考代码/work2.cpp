#include <iostream>
using namespace std;

class Time
{
private:
	int hour, minute, second;

public:
	Time(int h = 1, int m = 1, int s = 1) : hour(h), minute(m), second(s) {}
	Time operator+(const Time &T);
	Time operator-(const Time &T);
	friend ostream &operator<<(ostream &out, const Time &T);
	friend istream &operator>>(istream &in, Time &T);
};

Time Time::operator+(const Time &T){
	Time tmp;
	tmp.hour = hour + T.hour;
	tmp.minute = minute + T.minute;
	tmp.second = second + T.second;
	if (second > 60)
	{
		second -= 60;
		minute++;
	}
	if (minute > 60)
	{
		minute -= 60;
		hour++;
	}
	if (hour > 23)
	{
		hour = 0;
	}
	return tmp;
}
Time Time::operator-(const Time &T){
	Time tmp;
	tmp.hour = hour - T.hour;
	tmp.minute = minute - T.minute;
	tmp.second = second - T.second;
	if(tmp.second < 0){
		tmp.second += 60;
		tmp.minute--;
	}
	if(tmp.minute<0){
		tmp.minute += 60;
		tmp.hour--;
	}
	if(hour<0){
		hour += 24; 
	}
	return tmp;
}

ostream &operator<<(ostream &out, const Time &T)
{
	out << T.hour << "ʱ" << T.minute << "��" << T.second << "��";
	return out;
}

istream &operator>>(istream &in, Time &T)
{
	in >> T.hour >> T.minute >> T.second;
	return in;
}

int main()
{
	Time t1;
	cout << t1 << endl;
	Time t2(20, 23, 40);
	cout << t2 << endl;
	Time t3 = t1 + t2;
	cout << t3 << endl;

	cout<<"������һ��ʱ�䣺"<<endl; 
	Time t4;
	cin >> t4;
	cout << t4 << endl;
	Time t5 = t3 - t4;
	cout << t5 << endl;
}
