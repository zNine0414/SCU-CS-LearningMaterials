#include <iostream>
using namespace std;

int getDay(int year, int month)
{
	int a[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
	{
		a[1] = 29;
	}
	return a[month - 1];
}
class Date
{
private:
	int year, month, day;

public:
	Date(int y = 1, int m = 1, int d = 1) : year(y), month(m), day(d){};
	friend Date operator+(Date date, int d);
	friend Date operator-(Date date, int d);
	friend ostream &operator<<(ostream &out, const Date &D);
	friend istream &operator>>(istream &in, Date &D);
};

Date operator+(Date date, int d)
{
	Date newDate;
	newDate.year = date.year;
	newDate.month = date.month;
	newDate.day = date.day + d;
	int max = getDay(newDate.year, newDate.month);
	while (newDate.day > max)
	{
		newDate.day -= max;
		newDate.month++;
		max = getDay(newDate.year, newDate.month);
	}
	while (newDate.month > 12)
	{
		newDate.year++;
		newDate.month -= 12;
	}
	return newDate;
}
Date operator-(Date date, int d)
{
	Date newDate;
	newDate.year = date.year;
	newDate.month = date.month;
	newDate.day = date.day - d;
	int max = getDay(newDate.year, newDate.month);
	while (newDate.day < 1)
	{
		--newDate.month;
		newDate.day += max;
		max = getDay(newDate.year, newDate.month);
	}
	while (newDate.month < 1)
	{
		--newDate.year;
		newDate.month += 12;
	}
	return newDate;
}

ostream &operator<<(ostream &out, const Date &D)
{
	out << D.year << "��" << D.month << "��" << D.day << "��";
	return out;
}

istream &operator>>(istream &in, Date &D)
{
	in >> D.year >> D.month >> D.day;
	return in;
}

int main()
{
	Date d2(2021, 4, 25);
	cout << d2 << endl;
	cout << "������һ�����ڣ�";

	Date d3;
	cin >> d3;
	cout << d3 << endl;
	cout << d3 + 50 << endl;
	cout << d3 - 100 << endl;

	return 0;
}
