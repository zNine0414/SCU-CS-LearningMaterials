#include<iostream>
	
using namespace std;

class Staff{
	private:
		int num;
		string name;
		double rateOfAttend;
		int basicSal;
		int prize;
		
	public:
		 Staff():num(0), name(""), rateOfAttend(0), basicSal(0), prize(0){
		 	
		 };
		 
		 Staff(int nu, string nm, double roa, int bS, int p):num(nu), name(nm), rateOfAttend(roa), basicSal(bS), prize(p){
		 	
		 };
		 
		 void Output(){
		 	cout<<name<<" �Ļ�����Ϣ����: "<<endl;
			cout<<"���"<<num<<" ������"<<rateOfAttend<<endl;
			cout<<"��������"<<basicSal<<" ����"<<prize<<endl;	
		 };
		 
		 void OutputWage(){
		 	cout<<"ʵ������Ϊ"<<basicSal+prize*rateOfAttend<<endl;
		 };
		 
		 double getBas(){
		 	return basicSal+prize*rateOfAttend;
		 }
};

class Saleman : virtual public Staff
{
	private:
		double deductRate;
		int personAmount;
		
	public:
		Saleman():deductRate(0), personAmount(0){
			
		};
		
		Saleman(int nu, string nm, double roa, int bS, int p, double dR, int pA):Staff(nu, nm, roa, bS, p), deductRate(dR), personAmount(pA){
			
		};
		
		void Output(){
			Staff::Output();
			cout<<"��ɱ���"<<deductRate<<" �������۶�"<<personAmount<<endl;
		};

		void OutputWage(){
		 	cout<<"ʵ������Ϊ"<<getBas()+deductRate*personAmount<<endl;
		};
		
		double getSale(){
			return deductRate*personAmount;
		};
};

class Manager : virtual public Staff
{
	private:
		double totalDeductRate;
		int totalAmount;
		
	public:
		Manager():totalDeductRate(0), totalAmount(0){
			
		};
		
		Manager(int nu, string nm, double roa, int bS, int p, double tDR, int tA):Staff(nu, nm, roa, bS, p), totalDeductRate(tDR), totalAmount(tA){
			
		};
		
		void Output(){
			Staff::Output();
			cout<<"������ɱ���"<<totalDeductRate<<" �����۶�"<<totalAmount<<endl;
		};
		
		void OutputWage(){
		 	cout<<"ʵ������Ϊ"<<getBas()+totalDeductRate*totalAmount<<endl;
		};
		
		pair<double, int> getM(){
			return pair<double, int>(totalDeductRate, totalAmount);
		};
		
		double getMana(){
			return totalDeductRate*totalAmount;
		};
};

class SaleManager : public Saleman, public Manager
{		
	public:
		SaleManager(){
			
		};
		
		SaleManager(int nu, string nm, double roa, int bS, int p, double dR, int pA, double tDR, int tA):Staff(nu, nm, roa, bS, p), Saleman(nu, nm, roa, bS, p, dR, pA), Manager(nu, nm, roa, bS, p, tDR, tA){
			
		};
		
		void Output(){
			Saleman::Output();
			cout<<"������ɱ���"<<getM().first<<" �����۶�"<<getM().second<<endl;
		};
		
		void OutputWage(){
		 	cout<<"ʵ������Ϊ"<<getBas()+getSale()+getMana()<<endl;
		};
};


int main()
{
	cout<<"test1:"<<endl;
	Staff ts1(1, "boss", 0.1, 99999, 100000);
	ts1.Output();
	ts1.OutputWage();
	
	cout<<endl<<"test2:"<<endl;
	Saleman ts2(2, "Sal", 0.9, 99, 100, 0.1, 100);
	ts2.Output(); 
	ts2.OutputWage();
	
	cout<<endl<<"test3:"<<endl;
	Manager ts3(3, "Mana", 0.7, 999, 10000, 0.5, 100000);
	ts3.Output();
	ts3.OutputWage();
	
	cout<<endl<<"test4:"<<endl;
	SaleManager ts4(4, "SM", 0.3, 9999, 10000, 0.7, 10000, 0.7, 100000);
	ts4.Output();
	ts4.OutputWage();
	
	
	cout<<endl<<"test5:"<<endl;
	SaleManager ts5;
	ts5.Output();
	ts5.OutputWage();
}
