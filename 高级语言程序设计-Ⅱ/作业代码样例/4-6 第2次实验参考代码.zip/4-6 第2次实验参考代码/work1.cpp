#include<iostream>
	
using namespace std;

class Person{
	private:
		string name;
		int age;
		string sex;
		
	public:
		 Person():name(""), age(0), sex(""){
		 	
		 };
		 
		 Person(string nm, int a, string s):name(nm), age(a), sex(s){
		 	
		 };
		 
		 void Show(){
		 	cout<<name<<" "<<age<<"�� �Ա�"<<sex<<endl;	
		 };
};

class Teacher : virtual public Person
{
	private:
		string title;
		
	public:
		Teacher():title(""){
			
		};
		
		Teacher(string nm, int a, string s, string ti):Person(nm, a, s), title(ti){
			
		};
		
		void Show(){
			Person::Show();
			cout<<"ְ��Ϊ"<<title<<endl;
		};

};

class Cadre : virtual public Person
{
	private:
		string post;
		
	public:
		Cadre():post(""){
			
		};
		
		Cadre(string nm, int a, string s, string po):Person(nm, a, s), post(po){
			
		};
		
		void Show(){
			Person::Show();
			cout<<"ְ��Ϊ"<<post<<endl;
		};
		
		string getPost(){
			return post;
		};
};

class TeacherCadre : public Teacher, public Cadre
{
	private:
		int wages;
		
	public:
		TeacherCadre():wages(0){
			
		};
		
		TeacherCadre(string nm, int a, string s, string ti, string po, int w):Person(nm, a, s), Teacher(nm, a, s, ti), Cadre(nm, a, s, po), wages(w){
			
		};
		
		void Show(){
			Teacher::Show();
			cout<<"ְ��Ϊ"<<Cadre::getPost()<<endl;
			cout<<"����Ϊ"<<wages<<endl; 
		};
};


int main()
{
	cout<<"test1:"<<endl;
	Person ts1("boss", 33, "��");
	ts1.Show();
	
	cout<<endl<<"test2:"<<endl;
	Teacher ts2("teacher", 22, "Ů", "Ӣ����ʦ");
	ts2.Show(); 
	
	cout<<endl<<"test3:"<<endl;
	Cadre ts3("cadre", 55, "��", "��������");
	ts3.Show();
	
	cout<<endl<<"test4:"<<endl;
	TeacherCadre ts4("TCTC", 99, "Ů", "��ѧ��ʦ", "У��", 999999);
	ts4.Person::Show();
	ts4.Teacher::Show();
	ts4.Cadre::Show();
	ts4.Show();
	
	cout<<endl<<"test5:"<<endl;
	TeacherCadre ts5;
	ts5.Show();
}
