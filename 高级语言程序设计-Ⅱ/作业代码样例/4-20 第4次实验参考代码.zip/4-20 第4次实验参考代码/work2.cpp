#include<iostream>

using namespace std;

class Shape{
public:
	static double totalS;
	static void ShowTotal();
	virtual void ShowArea() = 0;
};
double Shape::totalS = 0;
void Shape::ShowTotal(){
	cout<<"��ǰͼ�������Ϊ"<<totalS<<endl<<endl; 
}

class Circle: public Shape{
private:
	int r;
	double s;

public:
	Circle(): r(0), s(0){}
	Circle(int radius): r(radius), s(radius*radius*3.14){
		totalS += s;
	}
	~Circle(){
		totalS -= s;
	}
	void ShowArea(){
		cout<<"Բ�����Ϊ"<<s<<endl;
	}
};

class Rectangle: public Shape{
private:
	int a, b;
	double s;
	
public:
	Rectangle(): a(0), b(0), s(0){}
	Rectangle(int t1, int t2): a(t1), b(t2), s(t1*t2){
		totalS += s;
	}
	~Rectangle(){
		totalS -= s;
	}
	
	void ShowArea(){
		cout<<"���ε����Ϊ"<<s<<endl;
	}
};

class Square: public Shape{
private:
	int n;
	double s;
	
public:
	Square(): n(0), s(0){}
	Square(int N): n(N), s(N*N){
		totalS += s;
	}
	~Square(){
		totalS -= s;
	}
	
	void ShowArea(){
		cout<<"�����ε����Ϊ"<<s<<endl;
	}
};


void ShapeShow(Shape *ts){
	ts->ShowArea();
}


int main(){
	Shape::ShowTotal();
	
	Shape* ps[3];
	ps[0] = new Circle(5);
	ps[1] = new Rectangle(5, 6);
	ps[2] = new Square(5);
	for(int i=0;i<3;i++){
		ps[i]->ShowArea();
	}
	
	cout<<endl;
	Shape::ShowTotal();
}







