#include<iostream>

using namespace std;

class Shape{
public:
	static double totalS;
	static void ShowTotal();
	virtual void Show() = 0;
};
double Shape::totalS = 0;
void Shape::ShowTotal(){
	cout<<"��ǰͼ�������Ϊ"<<totalS<<endl<<endl; 
}


class Circle: public Shape{
private:
	int r;
	double s;

public:
	Circle(): r(0), s(0){}
	Circle(int radius): r(radius), s(radius*radius*3.14){
		totalS += s;
	}
	~Circle(){
		totalS -= s;
	}
	
	void Show(){
		cout<<"Բ�İ뾶Ϊ"<<r<<"\t���Ϊ"<<s<<endl;
	}
};

class Rectangle: public Shape{
private:
	int a, b;
	double s;
	
public:
	Rectangle(): a(0), b(0), s(0){}
	Rectangle(int t1, int t2): a(t1), b(t2), s(t1*t2){
		totalS += s;
	}
	~Rectangle(){
		totalS -= s;
	}
	
	void Show(){
		cout<<"���εĳ�Ϊ"<<a<<"��Ϊ"<<b<<"\t���Ϊ"<<s<<endl;
	}
};

void ShapeShow(Shape &ts){
	ts.Show();
}


int main(){
	Shape::ShowTotal();
	
	Circle c1;
	ShapeShow(c1);
	Circle c2(5);
	ShapeShow(c2);
	
	Rectangle r1;
	ShapeShow(r1);
	Rectangle r2(5, 6);
	ShapeShow(r2);
	
	Shape::ShowTotal();
}
